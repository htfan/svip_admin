<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?><?php defined('BASEPATH') or exit('No permission resources.'); ?>
<div class='panel panel-default grid'>
    <div class='panel-heading'>
        <i class='fa fa-table'></i> 服务商列表
        <div class='panel-tools'>
            <div class='btn-group'>
                 <a class="btn " href="<?php echo base_url('adminpanel/server/add')?>"><span class="glyphicon glyphicon-plus"></span> 添加 </a>             </div>
            <div class='badge'><?php echo count($data_list)?></div>
        </div>
    </div>
        <form method="post" id="form_list"  action="<?php echo base_url('adminpanel/server/delete_all')?>"  > 
    <div class='panel-body '>
    <?php if($data_list):?>
        <table class="table table-hover dataTable" id="checkAll">
          <thead>
            <tr>
              <th>#</th>
              <th>操作</th>
            </tr>
          </thead>
          <tbody>
          <?php foreach($data_list as $k=>$v):?>
            <tr>
              <td><input type="checkbox" name="pid[]" value="<?php echo $v['server_id']?>" /></td>
               <td>
                            	<a href="<?php echo base_url('adminpanel/server/readonly/'.$v['server_id'])?>"  class="btn btn-default btn-xs"><span class="glyphicon glyphicon-share-alt"></span> 查看</a>
                                            <a href="<?php echo base_url('adminpanel/server/edit/'.$v['server_id'])?>"  class="btn btn-default btn-xs"><span class="glyphicon glyphicon-edit"></span> 修改</a>
                                            <button type="button" class="btn btn-default btn-xs delete-btn" value="<?php echo $v['server_id'];?>"><span class="glyphicon glyphicon-remove"></span> 删除</button>
                
              </td>
            </tr>
            <?php endforeach;?>
            
          </tbody>
        </table> 
    	</div>
      <div class="panel-footer">
        <div class="pull-left">
          <div class="btn-group">
                  <button type="button" class="btn btn-default" id="reverseBtn"><span class="glyphicon glyphicon-ok"></span> 反选</button>
            <button type="button" id="deleteBtn"  class="btn btn-default"><span class="glyphicon glyphicon-remove"></span> 删除勾选</button>
                 </div>
      </div>
        <div class="pull-right">
        <?php echo $pages;?>
        </div>
      </div> 
      </form>  
  </div>
<?php else:?>
    <div class="no-result">-- 暂无数据 -- </div>
<?php endif;?>

<script language="javascript" type="text/javascript">
<!--
	$(document).ready(function(e) {
        $("#reverseBtn").click(function(){
			TS.Page.UI.ReverseChecked('pid[]')
		});
		
		$(".delete-btn").click(function(){
			var v = $(this).val();
			if(confirm('确定要删除吗?'))
			{
				window.location.href='<?php echo base_url('adminpanel/server/')?>/delete_one/'+v;
			}
		});
		
		$("#deleteBtn").click(function(){
			var _arr = TS.Common.Array.GetCheckedValue("pid[]");
			if(_arr.length==0)
			{
					alert("请先勾选明细");
					return false;
			}
			if(confirm('确定要删除吗?'))
			{
				$("#form_list").submit();
			}
		});
    });
-->
</script>
