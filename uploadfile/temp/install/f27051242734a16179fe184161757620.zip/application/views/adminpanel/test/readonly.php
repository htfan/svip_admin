<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?><?php defined('BASEPATH') or exit('No permission resources.'); ?>
<div class='panel panel-default '>
    <div class='panel-heading'>
        <i class='fa fa-table'></i> test 查看信息 
        <div class='panel-tools'>
            <div class='btn-group'>
            	<a class="btn " href="<?php echo base_url('adminpanel/test')?>"><span class="glyphicon glyphicon-arrow-left"></span> 返回 </a>
            </div>
        </div>
    </div>
    <div class='panel-body '>
<div class="form-horizontal"  >
	<fieldset>
        <legend>基本信息</legend>
     
  	  	
	<div class="form-group">
				<label for="title" class="col-sm-2 control-label form-control-static">标题</label>
				<div class="col-sm-9 form-control-static ">
					<?php echo isset($data_info['title'])?$data_info['title']:'' ?>
				</div>
			</div>
	  	
	<div class="form-group">
				<label for="url" class="col-sm-2 control-label form-control-static">跳转链接</label>
				<div class="col-sm-9 form-control-static ">
					<?php echo isset($data_info['url'])?$data_info['url']:'' ?>
				</div>
			</div>
	  	
	<div class="form-group">
				<label for="content" class="col-sm-2 control-label form-control-static">内容</label>
				<div class="col-sm-9 form-control-static ">
					<?php echo isset($data_info['content'])?$data_info['content']:'' ?>
				</div>
			</div>
	  	
	<div class="form-group">
				<label for="image" class="col-sm-2 control-label form-control-static">新闻图片</label>
				<div class="col-sm-9 ">
					<img src='<?php echo SITE_URL;?><?php echo  isset($data_info['image'])?('test_new_/'.$data_info['image']):'' ?>' width="100" />
				</div>
			</div>
	  	
	<div class="form-group">
				<label for="profile" class="col-sm-2 control-label form-control-static">简介</label>
				<div class="col-sm-9 form-control-static ">
					<?php echo isset($data_info['profile'])?$data_info['profile']:'' ?>
				</div>
			</div>
	  	
	<div class="form-group">
				<label for="email" class="col-sm-2 control-label form-control-static">邮箱</label>
				<div class="col-sm-9 form-control-static ">
					<?php echo isset($data_info['email'])?$data_info['email']:'' ?>
				</div>
			</div>
	  	
	<div class="form-group">
				<label for="mobile" class="col-sm-2 control-label form-control-static">手机号</label>
				<div class="col-sm-9 form-control-static ">
					<?php echo isset($data_info['mobile'])?$data_info['mobile']:'' ?>
				</div>
			</div>
	  	
	<div class="form-group">
				<label for="ymd" class="col-sm-2 control-label form-control-static">年月日</label>
				<div class="col-sm-9 form-control-static ">
					<?php echo isset($data_info['ymd'])?$data_info['ymd']:'' ?>
				</div>
			</div>
	  	
	<div class="form-group">
				<label for="ymdhis" class="col-sm-2 control-label form-control-static">年月日时分秒</label>
				<div class="col-sm-9 form-control-static ">
					<?php echo isset($data_info['ymdhis'])?$data_info['ymdhis']:'' ?>
				</div>
			</div>
	  	
	<div class="form-group">
				<label for="his" class="col-sm-2 control-label form-control-static">时分秒</label>
				<div class="col-sm-9 form-control-static ">
					<?php echo isset($data_info['his'])?$data_info['his']:'' ?>
				</div>
			</div>
	  	
	<div class="form-group">
				<label for="unique_num" class="col-sm-2 control-label form-control-static">唯一编号</label>
				<div class="col-sm-9 form-control-static ">
					<?php echo isset($data_info['unique_num'])?$data_info['unique_num']:'' ?>
				</div>
			</div>
	  	
	<div class="form-group">
				<label for="number" class="col-sm-2 control-label form-control-static">数字</label>
				<div class="col-sm-9 form-control-static ">
					<?php echo isset($data_info['number'])?$data_info['number']:'' ?>
				</div>
			</div>
	  	
	<div class="form-group">
				<label for="price" class="col-sm-2 control-label form-control-static">价格</label>
				<div class="col-sm-9 form-control-static ">
					<?php echo isset($data_info['price'])?$data_info['price']:'' ?>
				</div>
			</div>
	  	
	<div class="form-group">
				<label for="is_display" class="col-sm-2 control-label form-control-static">是否显示</label>
				<div class="col-sm-9 form-control-static ">
					<?php echo isset($data_info['is_display'])?$data_info['is_display']:'' ?>
				</div>
			</div>
	  	
	<div class="form-group">
				<label for="is_work" class="col-sm-2 control-label form-control-static">是否工作</label>
				<div class="col-sm-9 form-control-static ">
					<?php echo isset($data_info['is_work'])?$data_info['is_work']:'' ?>
				</div>
			</div>
	  	
	<div class="form-group">
				<label for="area" class="col-sm-2 control-label form-control-static">地区</label>
				<div class="col-sm-9 form-control-static ">
					<?php echo isset($data_info['area'])?$data_info['area']:'' ?>
				</div>
			</div>
	  	
	<div class="form-group">
				<label for="city" class="col-sm-2 control-label form-control-static">城市</label>
				<div class="col-sm-9 form-control-static ">
					<?php echo isset($data_info['city'])?$data_info['city']:'' ?>
				</div>
			</div>
	  	
	<div class="form-group">
				<label for="author_id" class="col-sm-2 control-label form-control-static">发布员id</label>
				<div class="col-sm-9 form-control-static ">
					<?php echo isset($data_info['author_id'])?$data_info['author_id']:'' ?>
				</div>
			</div>
	  	
	<div class="form-group">
				<label for="favorite" class="col-sm-2 control-label form-control-static">爱好</label>
				<div class="col-sm-9 form-control-static ">
					<?php echo isset($data_info['favorite'])?$data_info['favorite']:'' ?>
				</div>
			</div>
	  	
	<div class="form-group">
				<label for="course" class="col-sm-2 control-label form-control-static">课程</label>
				<div class="col-sm-9 form-control-static ">
					<?php echo isset($data_info['course'])?$data_info['course']:'' ?>
				</div>
			</div>
	  	
	<div class="form-group">
				<label for="author_ids" class="col-sm-2 control-label form-control-static">允许修改的人员</label>
				<div class="col-sm-9 form-control-static ">
					<?php echo isset($data_info['author_ids'])?$data_info['author_ids']:'' ?>
				</div>
			</div>
	  	
	<div class="form-group">
				<label for="file" class="col-sm-2 control-label form-control-static">下载文件</label>
				<div class="col-sm-9 ">
					<a href='<?php echo SITE_URL;?><?php echo isset($data_info['file'])?('test_file_/'.$data_info['file']):'' ?>' target="_blank" >点击查看</a>
				</div>
			</div>
	  	
	<div class="form-group">
				<label for="current_uid" class="col-sm-2 control-label form-control-static">当前用户id</label>
				<div class="col-sm-9 form-control-static ">
					<?php echo isset($data_info['current_uid'])?$data_info['current_uid']:'' ?>
				</div>
			</div>
	  	
	<div class="form-group">
				<label for="current_user" class="col-sm-2 control-label form-control-static">当前用户名</label>
				<div class="col-sm-9 form-control-static ">
					<?php echo isset($data_info['current_user'])?$data_info['current_user']:'' ?>
				</div>
			</div>
	  	
	<div class="form-group">
				<label for="current_time" class="col-sm-2 control-label form-control-static">当前系统时间</label>
				<div class="col-sm-9 form-control-static ">
					<?php echo isset($data_info['current_time'])?$data_info['current_time']:'' ?>
				</div>
			</div>
	    </fieldset>
	</div>
</div>
</div>
